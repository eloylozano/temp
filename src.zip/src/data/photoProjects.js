// src/data/photoProjects.js

export default [
  {
    slug: "sunsets",
    title: "Atardeceres",
    description:
      '"Atardeceres" es un proyecto visual que nace de la necesidad de detener el tiempo en ese momento exacto en que el sol roza el horizonte y el cielo se convierte en lienzo. Cada fotografía es un intento de capturar la calma, el fuego y la nostalgia que solo los atardeceres saben transmitir. No hay filtros, ni excesos, solo luz natural, colores sinceros y la belleza efímera de un instante que nunca se repite igual.',
    coverImage: "/images/projects/sunsets/banner.png",
    photos: [
      {
        title: "Ventana Al Atlántico",
        description:
          'Frente a la Ventana del Atlántico, el sol se rindió lentamente al mar, encajando con una precisión casi divina justo en el centro del horizonte. No era solo una puesta de sol, era un suspiro dorado suspendido entre el hierro forjado y la eternidad salada del océano. El viento olía a despedida y las sombras se estiraban como si quisieran agarrar el último hilo de luz. En ese instante, todo encajó: la calma, el fuego y la certeza de que algunos finales son, en realidad, la forma más hermosa que tiene el día de decirnos "hasta mañana".',
        image: "/images/projects/sunsets/ventanaAtlantico.png",
        tech: {
          focal: "50mm",
          aperture: "f/1.8",
          iso: "200",
          camera: "Canon EOS R",
          lens: "RF 50mm f/1.8 STM",
        },
      },
      {
        title: "Pita en el atardecer",
        description:
          "El sol descendía sobre Almería con la lentitud de quien sabe que está ofreciendo un espectáculo irrepetible. En primer plano, una pita se alzaba firme, casi ceremonial, como si saludara por última vez al astro que la ha curtido día tras día. A su alrededor, cactus silentes, testigos del calor, la soledad y la belleza áspera de esta tierra. La luz bañaba todo de un oro viejo, convirtiendo lo seco en sagrado, lo simple en eterno. Fue un atardecer que no pidió nada, solo estar presente y dejarse quemar suavemente por la luz.",
        image: "/images/projects/sunsets/PitaAtardecer.png",
        tech: {
          focal: "42mm",
          aperture: "f/6.7",
          iso: "400",
          camera: "Canon EOS 200D",
          lens: "EF 18-55mm f/4.5",
        },
      },
    ],
  },
  {
    slug: "nature",
    title: "Naturaleza",
    description:
      '"Naturaleza" es un proyecto visual que surge del deseo de conectar con lo esencial, de mirar más allá del ruido y encontrar belleza en lo simple. Cada imagen es un encuentro íntimo con la tierra: hojas que respiran, ramas que se estiran al cielo, texturas que hablan en silencio. No hay artificios, ni puestas en escena, solo la luz que cae como cae, los colores que son como son, y el pulso sereno de un mundo que florece sin pedir permiso.',
    coverImage: "/images/projects/nature/banner.png",
    photos: [
      {
        title: "Al filo del Atlántico",
        description:
          "Una roca solitaria se aferra al borde, como si dudara entre avanzar o quedarse, entre el salto y la quietud. En medio del viento atlántico y frente a la inmensidad del mar, se convierte en la protagonista silenciosa de una escena que parece detenida en el tiempo. Es ahí, al filo del acantilado, donde la naturaleza revela su manera de hablar sin palabras: con formas que resisten, con equilibrios que desafían, con belleza que no necesita explicaciones.",
        image: "/images/projects/nature/cliff.jpg",
        tech: {
          focal: "35mm",
          aperture: "f/4",
          iso: "320",
          camera: "Canon EOS R",
          lens: "RF 35mm f/1.8 Macro IS STM",
        },
      },
      {
        title: "Entre musgo y bruma",
        description:
          "El sonido del agua lo envuelve todo, como si el bosque respirara a través de la caída. No hay caminos marcados ni relojes aquí, solo el murmullo constante que arrastra hojas, tiempo y pensamiento. En la Fervenza do Rexedoiro, la naturaleza no se muestra imponente, sino íntima. Es un rincón escondido donde el agua no cae: danza. Y uno, por un momento, se siente parte de ese ritmo antiguo que no necesita palabras para ser entendido.",
        image: "/images/projects/nature/forest.jpg",
        tech: {
          focal: "50mm",
          aperture: "f/2.2",
          iso: "250",
          camera: "Canon EOS 200D",
          lens: "EF 50mm f/1.8 STM",
        },
      },
      {
        title: "Sin pasos en la playa",
        description:
          "La marea había borrado todo rastro de presencia humana. Ni huellas, ni castillos de arena, solo la piel tersa del océano besando la orilla como si fuera la primera vez. El viento hablaba en murmullos y el horizonte, limpio y vasto, parecía invitar al silencio. Era una playa sin historia aparente, pero cargada de memorias invisibles. En su desnudez, decía más que cualquier multitud: que la belleza también existe cuando nadie la mira.",
        image: "/images/projects/nature/beach.jpg",
        tech: {
          focal: "50mm",
          aperture: "f/2.2",
          iso: "250",
          camera: "Canon EOS 200D",
          lens: "EF 50mm f/1.8 STM",
        },
      },
    ],
  },
];
